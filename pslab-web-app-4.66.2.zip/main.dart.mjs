// Compiles a dart2wasm-generated main module from `source` which can then
// be instantiated via the `instantiate` method.
//
// `source` needs to be a `Response` object (or promise thereof) e.g. created
// via the `fetch()` JS API.
export async function compileStreaming(source) {
  const builtins = {builtins: ['js-string'], importedStringConstants: ''};
  return new CompiledApp(
      await _compileStreaming(source, builtins), builtins);
}

// Compiles a dart2wasm-generated wasm module from `bytes` which is then
// instantiable via the `instantiate` method.
export async function compile(bytes) {
  const builtins = {builtins: ['js-string'], importedStringConstants: ''};
  return new CompiledApp(await WebAssembly.compile(bytes, builtins), builtins);
}

let _isCompileStreamingSupported;
async function _compileStreaming(source, builtins) {
  _isCompileStreamingSupported ??= WebAssembly.compileStreaming(
    new Response(
      new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,2,23,1,14,119,97,115,109,58,106,115,45,115,116,114,105,110,103,4,99,97,115,116,0,0]),
      {headers: {'Content-Type': 'application/wasm'}},
    ),
    builtins,
  ).then(() => false, (e) => e instanceof WebAssembly.CompileError);
  if (await _isCompileStreamingSupported) {
    return WebAssembly.compileStreaming(source, builtins);
  }
  return WebAssembly.compile(await (await source).arrayBuffer(), builtins);
}

class CompiledApp {
  constructor(module, builtins) {
    this.module = module;
    this.builtins = builtins;
  }

  // The second argument is an options object containing:
  // `loadDeferredModules` is a JS function that takes an array of module names
  //   matching wasm files produced by the dart2wasm compiler. It also takes a
  //   callback that should be invoked for each loaded module with 2 arguments:
  //   (1) the module name, (2) the loaded module in a format supported by
  //   `WebAssembly.compile` or `WebAssembly.compileStreaming`. The callback
  //   returns a Promise that resolves when the module is instantiated.
  //   loadDeferredModules should return a Promise that resolves when all the
  //   modules have been loaded and the callback promises have resolved.
  // `loadDeferredId` is a JS function that takes load ID produced by the
  //   compiler when the `use-load-ids` option is passed. Each load ID maps to
  //   one or more wasm files as specified in the emitted JSON file. It also
  //   takes a callback that should be invoked for each loaded module with 2
  //   arguments: (1) the module name, (2) the loaded module in a format
  //   supported by `WebAssembly.compile` or `WebAssembly.compileStreaming`.
  //   The callback returns a Promise that resolves when the module is
  //   instantiated.
  //   loadDeferredId should return a Promise that resolves when all the
  //   modules have been loaded and the callback promises have resolved.
  async instantiate(additionalImports, {loadDeferredModules, loadDeferredId} = {}) {
    let dartInstance;

    // Prints to the console
    function printToConsole(value) {
      if (typeof dartPrint == "function") {
        dartPrint(value);
        return;
      }
      if (typeof console == "object" && typeof console.log != "undefined") {
        console.log(value);
        return;
      }
      if (typeof print == "function") {
        print(value);
        return;
      }

      throw "Unable to print message: " + value;
    }

    // A special symbol attached to functions that wrap Dart functions.
    const jsWrappedDartFunctionSymbol = Symbol("JSWrappedDartFunction");

    function finalizeWrapper(dartFunction, wrapped) {
      wrapped.dartFunction = dartFunction;
      wrapped[jsWrappedDartFunctionSymbol] = true;
      return wrapped;
    }

    // Imports
    const dart2wasm = {
            AB: b => !!b,
      AC: Function.prototype.call.bind(DataView.prototype.setInt16),
      AD: x0 => x0.height,
      AE: x0 => x0.computedStyleMap(),
      AF: x0 => x0.clientX,
      AG: x0 => x0.current(),
      AH: x0 => x0.value,
      AI: () => Date.now(),
      AJ: x0 => x0.width,
      AK: x0 => x0.type,
      AL: (x0,x1) => ({vendorId: x0,productId: x1}),
      AM: x0 => x0.code,
      AN: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      AO: (x0,x1) => x0.querySelector(x1),
      AP: (x0,x1) => { x0.draggable = x1 },
      B: s => printToConsole(s),
      BB: () => globalThis.document,
      BC: Function.prototype.call.bind(DataView.prototype.setUint16),
      BD: x0 => x0.width,
      BE: (x0,x1) => x0.get(x1),
      BF: x0 => x0.changedTouches,
      BG: (x0,x1) => new Intl.v8BreakIterator(x0,x1),
      BH: x0 => x0.selectionDirection,
      BI: (x0,x1,x2,x3,x4) => x0.frb_pde_ffi_dispatcher_sync(x1,x2,x3,x4),
      BJ: (x0,x1,x2,x3,x4,x5) => x0.createImageBitmap(x1,x2,x3,x4,x5),
      BK: x0 => x0.response,
      BL: x0 => ({filters: x0}),
      BM: x0 => x0.repeat,
      BN: (x0,x1) => { x0.onerror = x1 },
      BO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      BP: x0 => x0.maxTouchPoints,
      C: Function.prototype.call.bind(Number.prototype.toString),
      CB: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      CC: Function.prototype.call.bind(DataView.prototype.setUint8),
      CD: x0 => x0.screen,
      CE: (o, p) => p in o,
      CF: x0 => x0.key,
      CG: x0 => x0.v8BreakIterator,
      CH: x0 => x0.selectionStart,
      CI: () => globalThis.window,
      CJ: (x0,x1,x2) => x0.createImageBitmap(x1,x2),
      CK: (x0,x1) => { x0.responseType = x1 },
      CL: (x0,x1) => x0.requestDevice(x1),
      CM: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      CN: (x0,x1) => { x0.onreading = x1 },
      CO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      CP: x0 => x0.hardwareConcurrency,
      D: Function.prototype.call.bind(BigInt.prototype.toString),
      DB: (x0,x1) => x0.focus(x1),
      DC: Function.prototype.call.bind(DataView.prototype.setInt8),
      DD: o => {
        if (o === null || o === undefined) return 0;
        if (typeof(o) === 'string') return 1;
        return 2;
      },
      DE: (x0,x1) => { x0.textContent = x1 },
      DF: x0 => x0.identifier,
      DG: () => globalThis.Intl,
      DH: x0 => x0.selectionEnd,
      DI: (x0,x1,x2,x3,x4,x5) => x0.frb_pde_ffi_dispatcher_primary(x1,x2,x3,x4,x5),
      DJ: (x0,x1) => x0.createImageBitmap(x1),
      DK: x0 => x0.vendor,
      DL: x0 => x0.open(),
      DM: x0 => globalThis.Wakelock.toggle(x0),
      DN: x0 => x0.z,
      DO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      DP: x0 => x0.vendorSub,
      E: (exn) => {
        let stackString = exn.toString();
        let frames = stackString.split('\n');
        let drop = 4;
        if (frames[0].startsWith('Error')) {
            drop += 1;
        }
        return frames.slice(drop).join('\n');
      },
      EB: () => ({}),
      EC: Function.prototype.call.bind(DataView.prototype.getInt8),
      ED: x0 => x0.tabIndex,
      EE: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      EF: x0 => x0.touches,
      EG: (x0,x1) => x0.segment(x1),
      EH: (x0,x1) => { x0.name = x1 },
      EI: (x0,x1) => x0.releaseInterface(x1),
      EJ: x0 => new Blob(x0),
      EK: x0 => new Blob(x0),
      EL: (x0,x1) => x0.selectConfiguration(x1),
      EM: (x0,x1) => x0.appendChild(x1),
      EN: x0 => x0.y,
      EO: (x0,x1) => { x0.onerror = x1 },
      EP: x0 => x0.productSub,
      F: () => new Error().stack,
      FB: (o, p, v) => o[p] = v,
      FC: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Int8Array) return 1;
        return 2;
      },
      FD: (x0,x1) => x0.contains(x1),
      FE: x0 => x0.matches,
      FF: x0 => x0.pressure,
      FG: x0 => x0.index,
      FH: (x0,x1) => { x0.placeholder = x1 },
      FI: x0 => x0.close(),
      FJ: x0 => x0.close(),
      FK: x0 => ({type: x0}),
      FL: (x0,x1) => x0.claimInterface(x1),
      FM: x0 => x0.id,
      FN: x0 => x0.x,
      FO: (x0,x1) => { x0.oncancel = x1 },
      FP: x0 => x0.product,
      G: s => JSON.stringify(s),
      GB: () => [],
      GC: (o, start, length) => new Float64Array(o.buffer, o.byteOffset + start, length),
      GD: x0 => x0.activeElement,
      GE: (x0,x1) => x0.matchMedia(x1),
      GF: x0 => x0.tiltY,
      GG: x0 => x0.next(),
      GH: (x0,x1) => { x0.autocomplete = x1 },
      GI: (x0,x1,x2,x3,x4) => ({requestType: x0,recipient: x1,request: x2,value: x3,index: x4}),
      GJ: x0 => x0.naturalHeight,
      GK: (x0,x1) => new Blob(x0,x1),
      GL: (x0,x1,x2) => x0.selectAlternateInterface(x1,x2),
      GM: (x0,x1) => { x0.id = x1 },
      GN: x0 => new Magnetometer(x0),
      GO: (x0,x1) => { x0.onchange = x1 },
      GP: x0 => x0.platform,
      H: Function.prototype.call.bind(Number.prototype.toString),
      HB: (a, i) => a.push(i),
      HC: (o, start, length) => new Float32Array(o.buffer, o.byteOffset + start, length),
      HD: x0 => x0.parentNode,
      HE: x0 => x0.matches,
      HF: x0 => x0.tiltX,
      HG: x0 => x0.value,
      HH: (x0,x1) => { x0.type = x1 },
      HI: (x0,x1,x2) => x0.controlTransferOut(x1,x2),
      HJ: x0 => x0.naturalWidth,
      HK: x0 => globalThis.fetch(x0),
      HL: (x0,x1,x2) => x0.clearHalt(x1,x2),
      HM: (x0,x1) => { x0.async = x1 },
      HN: x0 => x0.start(),
      HO: x0 => globalThis.URL.createObjectURL(x0),
      HP: x0 => x0.languages,
      I: Function.prototype.call.bind(String.prototype.indexOf),
      IB: x0 => new Int8Array(x0),
      IC: (o, start, length) => new Uint32Array(o.buffer, o.byteOffset + start, length),
      ID: x0 => x0.tagName,
      IE: o => typeof o === 'function' && o[jsWrappedDartFunctionSymbol] === true,
      IF: x0 => x0.pointerType,
      IG: x0 => x0.done,
      IH: (x0,x1) => { x0.name = x1 },
      II: (x0,x1) => x0.controlTransferOut(x1),
      IJ: (x0,x1) => { x0.src = x1 },
      IK: x0 => x0.arrayBuffer(),
      IL: (x0,x1,x2) => x0.transferIn(x1,x2),
      IM: (x0,x1) => { x0.charset = x1 },
      IN: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      IO: x0 => x0.type,
      IP: x0 => x0.language,
      J: (s, p, i) => s.lastIndexOf(p, i),
      JB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI8ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      JC: (o, start, length) => new Int32Array(o.buffer, o.byteOffset + start, length),
      JD: x0 => x0.target,
      JE: f => f.dartFunction,
      JF: x0 => x0.pointerId,
      JG: (o, m, a) => o[m].apply(o, a),
      JH: (x0,x1) => { x0.placeholder = x1 },
      JI: x0 => x0.requestPort(),
      JJ: x0 => x0.displayHeight,
      JK: o => o.byteLength,
      JL: x0 => x0.data,
      JM: (x0,x1) => { x0.type = x1 },
      JN: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      JO: x0 => x0.lastModified,
      JP: x0 => x0.deviceMemory,
      K: o => o,
      KB: x0 => new Uint8Array(x0),
      KC: (o, start, length) => new Uint16Array(o.buffer, o.byteOffset + start, length),
      KD: x0 => x0.clientY,
      KE: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      KF: x0 => x0.getCoalescedEvents(),
      KG: x0 => x0.iterator,
      KH: (x0,x1) => { x0.scrollTop = x1 },
      KI: x0 => ({baudRate: x0}),
      KJ: x0 => x0.displayWidth,
      KK: (x0,x1,x2,x3) => x0.putImageData(x1,x2,x3),
      KL: x0 => x0.status,
      KM: (x0,x1) => x0.querySelector(x1),
      KN: (x0,x1) => { x0.onerror = x1 },
      KO: x0 => x0.size,
      KP: x0 => x0.appVersion,
      L: o => {
        if (o === undefined || o === null) return 0;
        if (typeof o === 'number') return 1;
        return 2;
      },
      LB: x0 => new Uint8ClampedArray(x0),
      LC: (o, start, length) => new Int16Array(o.buffer, o.byteOffset + start, length),
      LD: x0 => x0.clientX,
      LE: (wasmFunction,f) => finalizeWrapper(f, function(x0,x1) { return wasmFunction(f,arguments.length,x0,x1) }),
      LF: s => s.trimLeft(),
      LG: () => globalThis.Symbol,
      LH: (x0,x1,x2) => x0.setSelectionRange(x1,x2),
      LI: (x0,x1) => x0.open(x1),
      LJ: x0 => x0.duration,
      LK: x0 => x0.arrayBuffer(),
      LL: x0 => x0.configurationValue,
      LM: (x0,x1) => x0.canShare(x1),
      LN: (x0,x1) => { x0.onreading = x1 },
      LO: x0 => x0.name,
      LP: x0 => x0.appName,
      M: x0 => x0.index,
      MB: x0 => new Int16Array(x0),
      MC: (o, start, length) => new Uint8ClampedArray(o.buffer, o.byteOffset + start, length),
      MD: (x0,x1,x2) => x0.addEventListener(x1,x2),
      ME: (p, s, f) => p.then(s, (e) => f(e, e === undefined)),
      MF: s => s.toUpperCase(),
      MG: (x0,x1) => new Intl.Segmenter(x0,x1),
      MH: (x0,x1,x2) => x0.setSelectionRange(x1,x2),
      MI: (x0,x1) => ({dataTerminalReady: x0,requestToSend: x1}),
      MJ: (x0,x1) => ({frameIndex: x0,completeFramesOnly: x1}),
      MK: (x0,x1) => x0.transferFromImageBitmap(x1),
      ML: x0 => x0.configuration,
      MM: (x0,x1) => x0.share(x1),
      MN: x0 => x0.z,
      MO: (x0,x1) => x0.item(x1),
      MP: x0 => x0.appCodeName,
      N: o => String(o),
      NB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI16ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      NC: (o, start, length) => new Uint8Array(o.buffer, o.byteOffset + start, length),
      ND: (x0,x1,x2) => x0.setAttribute(x1,x2),
      NE: (o, i) => o[i],
      NF: x0 => x0.pop(),
      NG: x0 => x0.Segmenter,
      NH: s => {
        if (/[[\]{}()*+?.\\^$|]/.test(s)) {
            s = s.replace(/[[\]{}()*+?.\\^$|]/g, '\\$&');
        }
        return s;
      },
      NI: (x0,x1) => x0.setSignals(x1),
      NJ: (x0,x1) => x0.decode(x1),
      NK: x0 => x0.rasterEndMilliseconds,
      NL: x0 => x0.productName,
      NM: x0 => x0.message,
      NN: x0 => x0.y,
      NO: x0 => x0.length,
      NP: x0 => x0.extraAssets,
      O: o => o === undefined,
      OB: x0 => new Uint16Array(x0),
      OC: (o, start, length) => new Int8Array(o.buffer, o.byteOffset + start, length),
      OD: (x0,x1) => x0.closest(x1),
      OE: o => o.length,
      OF: x0 => x0.flags,
      OG: x0 => x0.buffer,
      OH: x0 => x0.keyCode,
      OI: x0 => x0.getWriter(),
      OJ: x0 => x0.image,
      OK: x0 => x0.rasterStartMilliseconds,
      OL: x0 => x0.protocol,
      OM: (x0,x1,x2,x3) => x0.open(x1,x2,x3),
      ON: x0 => x0.x,
      OO: x0 => x0.files,
      OP: x0 => x0.fontManifest,
      P: (x0,x1) => x0.exec(x1),
      PB: x0 => new Int32Array(x0),
      PC: (x0,x1) => x0.querySelector(x1),
      PD: (ms, c) =>
      setTimeout(() => dartInstance.exports.$invokeCallback(c),ms),
      PE: o => {
        if (o === undefined) return 1;
        var type = typeof o;
        if (type === 'boolean') return 2;
        if (type === 'number') return 3;
        if (type === 'string') return 4;
        if (o instanceof Array) return 5;
        if (ArrayBuffer.isView(o)) {
          if (o instanceof Int8Array) return 6;
          if (o instanceof Uint8Array) return 7;
          if (o instanceof Uint8ClampedArray) return 8;
          if (o instanceof Int16Array) return 9;
          if (o instanceof Uint16Array) return 10;
          if (o instanceof Int32Array) return 11;
          if (o instanceof Uint32Array) return 12;
          if (o instanceof Float32Array) return 13;
          if (o instanceof Float64Array) return 14;
          if (o instanceof DataView) return 15;
        }
        if (o instanceof ArrayBuffer) return 16;
        // Feature check for `SharedArrayBuffer` before doing a type-check.
        if (globalThis.SharedArrayBuffer !== undefined &&
            o instanceof SharedArrayBuffer) {
            return 17;
        }
        if (o instanceof Promise) return 18;
        return 19;
      },
      PF: (a, s) => a.join(s),
      PG: x0 => x0.wasmMemory,
      PH: (x0,x1) => x0.scrollIntoView(x1),
      PI: x0 => x0.getReader(),
      PJ: x0 => x0.close(),
      PK: x0 => x0.imageBitmaps,
      PL: (x0,x1,x2) => x0.close(x1,x2),
      PM: x0 => x0.click(),
      PN: (x0,x1) => x0.createMediaStreamSource(x1),
      PO: x0 => x0.target,
      PP: x0 => x0.assetManifest,
      Q: (x0,x1) => { x0.lastIndex = x1 },
      QB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI32ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      QC: (x0,x1) => x0.item(x1),
      QD: (handle) => clearTimeout(handle),
      QE: x0 => x0.language,
      QF: (x0,x1) => x0.error(x1),
      QG: () => globalThis.window._flutter_skwasmInstance,
      QH: x0 => x0.multiViewEnabled,
      QI: x0 => x0.read(),
      QJ: (x0,x1,x2,x3,x4) => ({type: x0,data: x1,premultiplyAlpha: x2,colorSpaceConversion: x3,preferAnimation: x4}),
      QK: (x0,x1) => { x0.height = x1 },
      QL: x0 => x0.close(),
      QM: x0 => x0.remove(),
      QN: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      QO: (x0,x1) => x0.replaceChildren(x1),
      QP: x0 => x0.buildConfig,
      R: o => o,
      RB: x0 => new Uint32Array(x0),
      RC: x0 => x0.length,
      RD: x0 => x0.maxTouchPoints,
      RE: (x0,x1,x2,x3) => x0.register(x1,x2,x3),
      RF: () => globalThis.console,
      RG: () => new TextDecoder(),
      RH: (x0,x1) => x0.replaceWith(x1),
      RI: x0 => x0.value,
      RJ: x0 => new window.ImageDecoder(x0),
      RK: (x0,x1) => { x0.width = x1 },
      RL: (x0,x1) => x0.send(x1),
      RM: (o, a) => o + a,
      RN: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      RO: (x0,x1,x2) => x0.setAttribute(x1,x2),
      RP: x0 => x0.length,
      S: (s, m) => {
        try {
          return new RegExp(s, m);
        } catch (e) {
          return String(e);
        }
      },
      SB: x0 => new Float32Array(x0),
      SC: (x0,x1) => x0.querySelectorAll(x1),
      SD: x0 => x0.platform,
      SE: () => globalThis.window.FinalizationRegistry,
      SF: s => s.trimRight(),
      SG: (map, o, v) => map.set(o, v),
      SH: (x0,x1) => { x0.className = x1 },
      SI: x0 => x0.done,
      SJ: x0 => x0.name,
      SK: x0 => x0.convertToBlob(),
      SL: () => new Array(),
      SM: x0 => x0.children,
      SN: x0 => x0.disconnect(),
      SO: (x0,x1) => { x0.accept = x1 },
      SP: x0 => x0.getReader(),
      T: o => o instanceof RegExp,
      TB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmF32ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      TC: (x0,x1) => x0.getAttribute(x1),
      TD: s => new Date(s * 1000).getTimezoneOffset() * 60,
      TE: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      TF: x0 => x0.blur(),
      TG: (map, o) => map.get(o),
      TH: (x0,x1) => { x0.tabIndex = x1 },
      TI: x0 => x0.readable,
      TJ: x0 => x0.repetitionCount,
      TK: (x0,x1,x2) => new ImageData(x0,x1,x2),
      TL: (x0,x1) => new WebSocket(x0,x1),
      TM: x0 => x0.body,
      TN: x0 => x0.getAudioTracks(),
      TO: (x0,x1) => { x0.multiple = x1 },
      TP: x0 => x0.value,
      U: (string, times) => string.repeat(times),
      UB: x0 => new Float64Array(x0),
      UC: x0 => x0.remove(),
      UD: Date.now,
      UE: x0 => new window.FinalizationRegistry(x0),
      UF: x0 => x0.button,
      UG: () => new WeakMap(),
      UH: (x0,x1) => { x0.action = x1 },
      UI: x0 => x0.writable,
      UJ: x0 => x0.frameCount,
      UK: (x0,x1) => x0.getContext(x1),
      UL: x0 => x0.reason,
      UM: (x0,x1) => { x0.download = x1 },
      UN: x0 => x0.stop(),
      UO: (x0,x1) => { x0.type = x1 },
      UP: x0 => x0.done,
      V: o => o,
      VB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmF64ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      VC: (x0,x1) => x0.appendChild(x1),
      VD: (x0,x1) => x0.contains(x1),
      VE: (x0,x1) => x0.unregister(x1),
      VF: (x0,x1) => x0.prepend(x1),
      VG: Function.prototype.call.bind(DataView.prototype.getBigInt64),
      VH: (x0,x1) => { x0.method = x1 },
      VI: x0 => x0.navigator,
      VJ: x0 => x0.selectedTrack,
      VK: (x0,x1) => new OffscreenCanvas(x0,x1),
      VL: x0 => x0.code,
      VM: (x0,x1) => { x0.display = x1 },
      VN: (x0,x1) => x0.removeTrack(x1),
      VO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      VP: x0 => x0.read(),
      W: o => {
        if (o === undefined || o === null) return 0;
        if (typeof o === 'boolean') return 1;
        return 2;
      },
      WB: x0 => new ArrayBuffer(x0),
      WC: (x0,x1) => x0.append(x1),
      WD: (decoder, codeUnits) => decoder.decode(codeUnits),
      WE: x0 => x0.preventDefault(),
      WF: x0 => x0.parentElement,
      WG: Function.prototype.call.bind(DataView.prototype.setBigInt64),
      WH: (x0,x1) => { x0.noValidate = x1 },
      WI: x0 => x0.isSecureContext,
      WJ: x0 => x0.completed,
      WK: x0 => x0.allocationSize(),
      WL: (o, t) => typeof o === t,
      WM: x0 => x0.style,
      WN: x0 => x0.close(),
      WO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      WP: x0 => x0.body,
      X: x0 => x0.dotAll,
      XB: (x0,x1,x2) => new Uint8Array(x0,x1,x2),
      XC: (x0,x1,x2,x3) => x0.setProperty(x1,x2,x3),
      XD: () => new TextDecoder("utf-8", {fatal: true}),
      XE: x0 => x0.parent,
      XF: x0 => x0.innerHeight,
      XG: (o, start, length) => new BigInt64Array(o.buffer, o.byteOffset + start, length),
      XH: x0 => x0.click(),
      XI: (x0,x1) => x0.write(x1),
      XJ: x0 => x0.ready,
      XK: (x0,x1) => x0.copyTo(x1),
      XL: x0 => x0.readyState,
      XM: (x0,x1) => { x0.href = x1 },
      XN: x0 => x0.state,
      XO: (x0,x1,x2) => ({enableHighAccuracy: x0,timeout: x1,maximumAge: x2}),
      XP: x0 => x0.assetBase,
      Y: x0 => x0.unicode,
      YB: (x0,x1,x2) => new DataView(x0,x1,x2),
      YC: x0 => x0.style,
      YD: () => new TextDecoder("utf-8", {fatal: false}),
      YE: x0 => x0.timeStamp,
      YF: x0 => x0.innerWidth,
      YG: (x0,x1,x2,x3) => x0.pushState(x1,x2,x3),
      YH: (x0,x1) => x0.getElementsByClassName(x1),
      YI: x0 => new WeakRef(x0),
      YJ: x0 => x0.tracks,
      YK: (x0,x1) => { x0.height = x1 },
      YL: (x0,x1) => { x0.binaryType = x1 },
      YM: (x0,x1) => ({files: x0,text: x1}),
      YN: (x0,x1) => { x0.onended = x1 },
      YO: (x0,x1,x2,x3) => x0.getCurrentPosition(x1,x2,x3),
      YP: x0 => x0.loader,
      Z: x0 => x0.ignoreCase,
      ZB: (o, p) => o[p],
      ZC: x0 => x0.debugShowSemanticsNodes,
      ZD: (a, i, v) => a[i] = v,
      ZE: (x0,x1) => x0.hasAttribute(x1),
      ZF: x0 => x0.height,
      ZG: x0 => x0.history,
      ZH: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmF32ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      ZI: x0 => x0.deref(),
      ZJ: () => globalThis.window.ImageDecoder,
      ZK: (x0,x1) => { x0.width = x1 },
      ZL: (x0,x1,x2) => x0.insertBefore(x1,x2),
      ZM: x0 => ({files: x0}),
      ZN: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      ZO: x0 => x0.message,
      ZP: () => globalThis._flutter,
      a: x0 => x0.multiline,
      aB: (o) => new DataView(o.buffer, o.byteOffset, o.byteLength),
      aC: (x0,x1) => x0.warn(x1),
      aD: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI8ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      aE: x0 => x0.type,
      aF: x0 => x0.width,
      aG: x0 => x0.search,
      aH: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmF64ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      aI: () => globalThis.WeakRef,
      aJ: x0 => x0.close(),
      aK: (x0,x1) => x0.toDataURL(x1),
      aL: x0 => x0.id,
      aM: x0 => ({text: x0}),
      aN: x0 => x0.suspend(),
      aO: x0 => x0.code,
      b: (exn) => {
        if (exn instanceof Error) {
          return exn.stack;
        } else {
          return null;
        }
      },
      bB: Function.prototype.call.bind(Object.getOwnPropertyDescriptor(DataView.prototype, 'byteLength').get),
      bC: x0 => x0.console,
      bD: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI16ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      bE: (x0,x1) => x0.getModifierState(x1),
      bF: x0 => x0.clientHeight,
      bG: x0 => x0.location,
      bH: (x0,x1) => x0.dispatchEvent(x1),
      bI: (o, offsetInBytes, lengthInBytes) => {
        var dst = new ArrayBuffer(lengthInBytes);
        new Uint8Array(dst).set(new Uint8Array(o, offsetInBytes, lengthInBytes));
        return new DataView(dst);
      },
      bJ: x0 => x0.close(),
      bK: (x0,x1,x2,x3) => x0.drawImage(x1,x2,x3),
      bL: x0 => x0.offsetHeight,
      bM: () => ({}),
      bN: (x0,x1) => x0.connect(x1),
      bO: x0 => x0.speed,
      c: (c) =>
      queueMicrotask(() => dartInstance.exports.$invokeCallback(c)),
      cB: o => o.byteOffset,
      cC: () => globalThis.window,
      cD: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI32ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      cE: x0 => x0.buttons,
      cF: x0 => x0.clientWidth,
      cG: x0 => x0.pathname,
      cH: (x0,x1) => x0.createEvent(x1),
      cI: (a, s, e) => a.slice(s, e),
      cJ: (x0,x1) => ({vendorId: x0,productId: x1}),
      cK: (x0,x1,x2,x3,x4,x5,x6,x7,x8,x9) => x0.drawImage(x1,x2,x3,x4,x5,x6,x7,x8,x9),
      cL: x0 => x0.offsetWidth,
      cM: (x0,x1,x2) => new File(x0,x1,x2),
      cN: x0 => x0.destination,
      cO: x0 => x0.heading,
      d: (x0,x1) => x0.didCreateEngineInitializer(x1),
      dB: o => o.buffer,
      dC: (o, c) => o instanceof c,
      dD: (s) => +s,
      dE: x0 => x0.ctrlKey,
      dF: x0 => x0.isConnected,
      dG: (x0,x1,x2,x3) => x0.replaceState(x1,x2,x3),
      dH: (x0,x1,x2,x3) => x0.initEvent(x1,x2,x3),
      dI: Function.prototype.call.bind(DataView.prototype.getBigUint64),
      dJ: x0 => ({filters: x0}),
      dK: (x0,x1) => x0.getContext(x1),
      dL: x0 => x0.stopPropagation(),
      dM: (x0,x1) => { x0.type = x1 },
      dN: (x0,x1) => { x0.onmessage = x1 },
      dO: x0 => x0.accuracy,
      e: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      eB: Function.prototype.call.bind(DataView.prototype.getUint8),
      eC: (x0,x1) => x0[x1],
      eD: s => {
        if (!/^\s*[+-]?(?:Infinity|NaN|(?:\.\d+|\d+(?:\.\d*)?)(?:[eE][+-]?\d+)?)\s*$/.test(s)) {
          return NaN;
        }
        return parseFloat(s);
      },
      eE: x0 => x0.getBoundingClientRect(),
      eF: x0 => x0.head,
      eG: o => {
        const proto = Object.getPrototypeOf(o);
        return proto === Object.prototype || proto === null;
      },
      eH: x0 => x0.readText(),
      eI: () => {
        return typeof process != "undefined" &&
               Object.prototype.toString.call(process) == "[object process]" &&
               process.platform == "win32"
      },
      eJ: (x0,x1) => x0.requestDevice(x1),
      eK: x0 => x0.format,
      eL: x0 => x0.disabled,
      eM: x0 => x0.userAgent,
      eN: x0 => x0.port,
      eO: x0 => x0.altitudeAccuracy,
      f: (wasmFunction,f) => finalizeWrapper(f, function() { return wasmFunction(f,arguments.length) }),
      fB: (b, o) => new DataView(b, o),
      fC: x0 => x0.length,
      fD: s => s.trim(),
      fE: x0 => x0.y,
      fF: (x0,x1) => { x0.content = x1 },
      fG: o => Object.keys(o),
      fH: x0 => x0.clipboard,
      fI: () => {
        // On browsers return `globalThis.location.href`
        if (globalThis.location != null) {
          return globalThis.location.href;
        }
        return null;
      },
      fJ: (x0,x1,x2,x3,x4) => ({requestType: x0,recipient: x1,request: x2,value: x3,index: x4}),
      fK: (x0,x1,x2,x3,x4) => x0.getImageData(x1,x2,x3,x4),
      fL: (x0,x1) => { x0.min = x1 },
      fM: (x0,x1) => x0.getItem(x1),
      fN: (x0,x1) => x0.addModule(x1),
      fO: x0 => x0.altitude,
      g: (x0,x1) => ({initializeEngine: x0,autoStart: x1}),
      gB: (b, o, l) => new DataView(b, o, l),
      gC: (string, token) => string.split(token),
      gD: x0 => x0.classList,
      gE: x0 => x0.x,
      gF: (x0,x1) => { x0.name = x1 },
      gG: x0 => x0.state,
      gH: (x0,x1) => x0.writeText(x1),
      gI: x0 => x0.abort(),
      gJ: (x0,x1) => x0.controlTransferOut(x1),
      gK: x0 => x0.data,
      gL: (x0,x1) => { x0.max = x1 },
      gM: x0 => x0.localStorage,
      gN: x0 => ({parameterData: x0}),
      gO: x0 => x0.timestamp,
      h: (wasmFunction,f) => finalizeWrapper(f, function(x0,x1) { return wasmFunction(f,arguments.length,x0,x1) }),
      hB: Function.prototype.call.bind(DataView.prototype.getFloat64),
      hC: o => o instanceof Array,
      hD: x0 => x0.relatedTarget,
      hE: x0 => x0.top,
      hF: (x0,x1) => x0.removeChild(x1),
      hG: x0 => x0.hash,
      hH: x0 => x0.unlock(),
      hI: () => new AbortController(),
      hJ: x0 => x0.close(),
      hK: (x0,x1) => x0.getRandomValues(x1),
      hL: (x0,x1) => { x0.disabled = x1 },
      hM: (x0,x1) => x0.key(x1),
      hN: (x0,x1,x2) => new AudioWorkletNode(x0,x1,x2),
      hO: x0 => x0.longitude,
      i: x0 => new Promise(x0),
      iB: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Float64Array) return 1;
        return 2;
      },
      iC: (a, i) => a[i],
      iD: x0 => x0.hasFocus(),
      iE: x0 => x0.left,
      iF: x0 => x0.firstChild,
      iG: x0 => x0.state,
      iH: (x0,x1) => x0.lock(x1),
      iI: (x0,x1,x2,x3,x4,x5) => ({method: x0,headers: x1,body: x2,credentials: x3,redirect: x4,signal: x5}),
      iJ: (x0,x1) => x0.selectConfiguration(x1),
      iK: () => globalThis.crypto,
      iL: (x0,x1) => { x0.scrollLeft = x1 },
      iM: x0 => x0.length,
      iN: x0 => x0.audioWorklet,
      iO: x0 => x0.latitude,
      j: (x0,x1,x2) => x0.call(x1,x2),
      jB: Function.prototype.call.bind(DataView.prototype.setFloat64),
      jC: a => a.length,
      jD: x0 => x0.shiftKey,
      jE: x0 => x0.scrollTop,
      jF: x0 => x0.viewConstraints,
      jG: (x0,x1) => x0.go(x1),
      jH: x0 => x0.orientation,
      jI: (x0,x1) => globalThis.fetch(x0,x1),
      jJ: (x0,x1) => x0.claimInterface(x1),
      jK: l => new DataView(new ArrayBuffer(l)),
      jL: (x0,x1) => { x0.spellcheck = x1 },
      jM: (x0,x1,x2) => x0.setItem(x1,x2),
      jN: x0 => x0.channelCount,
      jO: x0 => x0.coords,
      k: (constructor, args) => {
        const factoryFunction = constructor.bind.apply(
            constructor, [null, ...args]);
        return new factoryFunction();
      },
      kB: (t, s) => t.set(s),
      kC: (x0,x1) => x0.test(x1),
      kD: x0 => x0.body,
      kE: x0 => x0.offsetTop,
      kF: x0 => x0.hostElement,
      kG: (x0,x1) => x0.querySelectorAll(x1),
      kH: (x0,x1) => x0.querySelector(x1),
      kI: (x0,x1) => x0.get(x1),
      kJ: (x0,x1,x2) => x0.controlTransferIn(x1,x2),
      kK: x0 => x0.port2,
      kL: (x0,x1) => { x0.disabled = x1 },
      kM: x0 => x0.message,
      kN: x0 => ({sampleRate: x0}),
      kO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      l: x0 => new Array(x0),
      lB: Function.prototype.call.bind(DataView.prototype.setFloat32),
      lC: x0 => x0.userAgent,
      lD: x0 => x0.visibilityState,
      lE: x0 => x0.scrollLeft,
      lF: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      lG: (d, digits) => d.toFixed(digits),
      lH: (x0,x1) => { x0.title = x1 },
      lI: (wasmFunction,f) => finalizeWrapper(f, function(x0,x1,x2) { return wasmFunction(f,arguments.length,x0,x1,x2) }),
      lJ: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof DataView) return 1;
        return 2;
      },
      lK: x0 => x0.start(),
      lL: x0 => x0.frb_get_rust_content_hash(),
      lM: x0 => x0.name,
      lN: x0 => new AudioContext(x0),
      lO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      m: o => [o],
      mB: Function.prototype.call.bind(DataView.prototype.getFloat32),
      mC: x0 => x0.navigator,
      mD: (x0,x1,x2) => x0.removeEventListener(x1,x2),
      mE: x0 => x0.offsetLeft,
      mF: x0 => ({runApp: x0}),
      mG: x0 => x0.maxHeight,
      mH: (x0,x1) => x0.vibrate(x1),
      mI: (x0,x1) => x0.forEach(x1),
      mJ: x0 => x0.data,
      mK: x0 => x0.close(),
      mL: (x0,x1) => x0.call(x1),
      mM: x0 => ({frequency: x0}),
      mN: () => new AudioContext(),
      mO: (x0,x1,x2,x3) => x0.watchPosition(x1,x2,x3),
      n: (o0, o1) => [o0, o1],
      nB: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Float32Array) return 1;
        return 2;
      },
      nC: Function.prototype.call.bind(String.prototype.toLowerCase),
      nD: x0 => x0.disconnect(),
      nE: x0 => x0.offsetParent,
      nF: () => typeof dartUseDateNowForTicks !== "undefined",
      nG: x0 => x0.maxWidth,
      nH: x0 => x0.arrayBuffer(),
      nI: x0 => x0.name,
      nJ: (x0,x1,x2) => x0.controlTransferOut(x1,x2),
      nK: x0 => x0.data,
      nL: x0 => new Function(x0),
      nM: x0 => new Gyroscope(x0),
      nN: x0 => x0.sampleRate,
      nO: (x0,x1) => x0.clearWatch(x1),
      o: (o0, o1, o2) => [o0, o1, o2],
      oB: Function.prototype.call.bind(DataView.prototype.getUint32),
      oC: Object.is,
      oD: x0 => new Intl.Locale(x0),
      oE: x0 => x0.offsetY,
      oF: () => Date.now(),
      oG: x0 => x0.minHeight,
      oH: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof ArrayBuffer) return 1;
        if (globalThis.SharedArrayBuffer !== undefined &&
            o instanceof SharedArrayBuffer) {
          return 2;
        }
        return 3;
      },
      oI: x0 => x0.statusText,
      oJ: x0 => x0.open(),
      oK: x0 => x0.port1,
      oL: x0 => x0.call(),
      oM: x0 => x0.start(),
      oN: x0 => x0.getSettings(),
      oO: x0 => x0.geolocation,
      p: (o0, o1, o2, o3) => [o0, o1, o2, o3],
      pB: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Uint32Array) return 1;
        return 2;
      },
      pC: x0 => x0.vendor,
      pD: x0 => x0.region,
      pE: x0 => x0.offsetX,
      pF: () => 1000 * performance.now(),
      pG: x0 => x0.minWidth,
      pH: x0 => x0.status,
      pI: x0 => x0.url,
      pJ: x0 => x0.productId,
      pK: () => new MessageChannel(),
      pL: (x0,x1) => x0.warn(x1),
      pM: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      pN: x0 => ({audio: x0}),
      pO: x0 => globalThis.URL.revokeObjectURL(x0),
      q: (x0,x1,x2) => { x0[x1] = x2 },
      qB: Function.prototype.call.bind(DataView.prototype.getInt32),
      qC: (x0,x1) => x0.createTextNode(x1),
      qD: x0 => x0.script,
      qE: (o, p, r) => o.replace(p, () => r),
      qF: (x0,x1) => x0.requestAnimationFrame(x1),
      qG: (x0,x1) => x0.removeProperty(x1),
      qH: (x0,x1) => x0.fetch(x1),
      qI: x0 => x0.status,
      qJ: () => new FileReader(),
      qK: () => globalThis.AudioStream,
      qL: () => globalThis.console,
      qM: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      qN: (x0,x1) => x0.getUserMedia(x1),
      qO: (x0,x1) => { x0.target = x1 },
      r: (o, p) => o[p],
      rB: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Int32Array) return 1;
        return 2;
      },
      rC: (x0,x1) => { x0.id = x1 },
      rD: x0 => x0.language,
      rE: (o, p, r) => o.replaceAll(p, () => r),
      rF: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      rG: (x0,x1) => x0.add(x1),
      rH: x0 => x0.content,
      rI: x0 => x0.value,
      rJ: (x0,x1) => x0.readAsArrayBuffer(x1),
      rK: (x0,x1) => x0.push(x1),
      rL: () => globalThis.crossOriginIsolated,
      rM: (x0,x1) => { x0.onerror = x1 },
      rN: x0 => x0.mediaDevices,
      rO: (x0,x1,x2) => x0.addEventListener(x1,x2),
      s: () => globalThis,
      sB: o => o instanceof Uint16Array,
      sC: (x0,x1) => { x0.nonce = x1 },
      sD: x0 => x0.languages,
      sE: x0 => x0.deltaMode,
      sF: x0 => x0.now(),
      sG: x0 => x0.data,
      sH: x0 => x0.document,
      sI: x0 => x0.done,
      sJ: x0 => x0.result,
      sK: x0 => x0.resume(),
      sL: x0 => x0.canvasKitMaximumSurfaces,
      sM: x0 => x0.error,
      sN: x0 => ({name: x0}),
      sO: (x0,x1) => x0.removeChild(x1),
      t: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      tB: Function.prototype.call.bind(DataView.prototype.getUint16),
      tC: x0 => x0.nonce,
      tD: (x0,x1) => x0.observe(x1),
      tE: x0 => x0.deltaY,
      tF: x0 => x0.performance,
      tG: (x0,x1) => x0.removeAttribute(x1),
      tH: (a, i) => a.splice(i, 1),
      tI: x0 => x0.cancel(),
      tJ: (x0,x1,x2,x3) => x0.addEventListener(x1,x2,x3),
      tK: (x0,x1,x2,x3,x4,x5) => x0.init(x1,x2,x3,x4,x5),
      tL: x0 => x0.hostElement,
      tM: (x0,x1) => { x0.onreading = x1 },
      tN: (x0,x1) => x0.query(x1),
      tO: x0 => x0.firstChild,
      u: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      uB: o => o instanceof Int16Array,
      uC: () => globalThis.window.flutterConfiguration,
      uD: (wasmFunction,f) => finalizeWrapper(f, function(x0,x1) { return wasmFunction(f,arguments.length,x0,x1) }),
      uE: x0 => x0.deltaX,
      uF: x0 => new Uint8Array(x0),
      uG: (x0,x1) => { x0.value = x1 },
      uH: a => a.pop(),
      uI: x0 => x0.body,
      uJ: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      uK: (x0,x1) => x0.createElement(x1),
      uL: x0 => x0.location,
      uM: x0 => x0.z,
      uN: (o,s,v) => o[s] = v,
      uO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      v: (x0,x1) => ({addView: x0,removeView: x1}),
      vB: Function.prototype.call.bind(DataView.prototype.getInt16),
      vC: (x0,x1) => x0.attachShadow(x1),
      vD: x0 => new ResizeObserver(x0),
      vE: x0 => x0.wheelDeltaY,
      vF: (x0,x1,x2) => x0.slice(x1,x2),
      vG: (x0,x1) => { x0.value = x1 },
      vH: x0 => x0.debugSkipFontRetryDelay,
      vI: x0 => x0.headers,
      vJ: (x0,x1,x2,x3) => x0.removeEventListener(x1,x2,x3),
      vK: (x0,x1) => x0.append(x1),
      vL: (x0,x1) => x0.getModifierState(x1),
      vM: x0 => x0.y,
      vN: () => Symbol("jsBoxedDartObjectProperty"),
      vO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      w: (l, r) => l === r,
      wB: o => o instanceof Uint8ClampedArray,
      wC: (x0,x1) => x0.createElement(x1),
      wD: (x0,x1) => x0.getPropertyValue(x1),
      wE: x0 => x0.wheelDeltaX,
      wF: (x0,x1) => x0.decode(x1),
      wG: x0 => x0.value,
      wH: (x0,x1,x2) => x0.set(x1,x2),
      wI: x0 => x0.signal,
      wJ: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      wK: x0 => x0.head,
      wL: x0 => x0.metaKey,
      wM: x0 => x0.x,
      wN: x0 => x0.state,
      wO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      x: x0 => x0.random(),
      xB: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Uint8Array) return 1;
        return 2;
      },
      xC: x0 => x0.scale,
      xD: x0 => globalThis.parseFloat(x0),
      xE: x0 => x0.bottom,
      xF: (x0,x1) => x0.adoptText(x1),
      xG: x0 => x0.selectionDirection,
      xH: x0 => x0.fontFallbackBaseUrl,
      xI: x0 => x0.close(),
      xJ: () => new XMLHttpRequest(),
      xK: (x0,x1) => { x0.src = x1 },
      xL: x0 => x0.altKey,
      xM: x0 => new Accelerometer(x0),
      xN: x0 => x0.permissions,
      xO: x0 => x0.parentNode,
      y: () => globalThis.Math,
      yB: Function.prototype.call.bind(DataView.prototype.setInt32),
      yC: x0 => x0.visualViewport,
      yD: (x0,x1) => x0.getComputedStyle(x1),
      yE: x0 => x0.right,
      yF: x0 => x0.first(),
      yG: x0 => x0.selectionStart,
      yH: (handle) => clearInterval(handle),
      yI: (o, p, v) => o[p] = v,
      yJ: (x0,x1,x2,x3) => x0.open(x1,x2,x3),
      yK: () => globalThis.document,
      yL: x0 => x0.ctrlKey,
      yM: x0 => x0.start(),
      yN: x0 => x0.baseURI,
      yO: (x0,x1,x2) => x0.removeEventListener(x1,x2),
      z: (x0,x1,x2,x3) => x0.addEventListener(x1,x2,x3),
      zB: Function.prototype.call.bind(DataView.prototype.setUint32),
      zC: x0 => x0.devicePixelRatio,
      zD: x0 => x0.documentElement,
      zE: x0 => x0.clientY,
      zF: x0 => x0.next(),
      zG: x0 => x0.selectionEnd,
      zH: (ms, c) =>
      setInterval(() => dartInstance.exports.$invokeCallback(c), ms),
      zI: x0 => x0.height,
      zJ: x0 => x0.send(),
      zK: x0 => x0.uninit(),
      zL: x0 => x0.isComposing,
      zM: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      zN: x0 => x0.document,
      zO: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),

    };

    const baseImports = {
      _: dart2wasm,
      Math: Math,
      Date: Date,
      Object: Object,
      Array: Array,
      Reflect: Reflect,
      WebAssembly: {
        JSTag: WebAssembly.JSTag,
      },
      "": new Proxy({}, { get(_, prop) { return prop; } }),

    };

    

    dartInstance = await WebAssembly.instantiate(this.module, {
      ...baseImports,
      ...additionalImports,
      
    });

    return new InstantiatedApp(this, dartInstance);
  }
}

class InstantiatedApp {
  constructor(compiledApp, instantiatedModule) {
    this.compiledApp = compiledApp;
    this.instantiatedModule = instantiatedModule;
  }

  // Call the main function with the given arguments.
  invokeMain(...args) {
    this.instantiatedModule.exports.$invokeMain(args);
  }
}
